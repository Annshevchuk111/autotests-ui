from pages.dashboard.dashboard_page import DashboardPage
import pytest
import allure
from tools.allure.epics import AllureEpic
from tools.allure.features import AllureFeature
from tools.allure.stories import AllureStory
from allure_commons.types import Severity
from tools.routes import AppRoute
from config import settings

@pytest.mark.regression
@pytest.mark.dashboard
@pytest.mark.registration

@allure.epic(AllureEpic.LMS)
@allure.feature(AllureFeature.DASHBOARD)
@allure.story(AllureStory.DASHBOARD)

@allure.parent_suite(AllureEpic.LMS)
@allure.suite(AllureFeature.DASHBOARD)
@allure.sub_suite(AllureStory.DASHBOARD)
class TestDashboard:
    @allure.title("Check displaying of dashboard page")
    @allure.severity(Severity.NORMAL)
    def test_dashboard_displaying(self,dashboard_page_with_state: DashboardPage):
        dashboard_page_with_state.visit(AppRoute.DASHBOARD)
        dashboard_page_with_state.navbar.check_visible(settings.test_user.username)
        dashboard_page_with_state.dashboard.check_visible()
        dashboard_page_with_state.students_chart.check_visible('Students')
        dashboard_page_with_state.activities_chart.check_visible('Activities')
        dashboard_page_with_state.courses_chart.check_visible('Courses')
        dashboard_page_with_state.scores_chart.check_visible('Scores')

        dashboard_page_with_state.sidebar.check_visible()