import pytest
from pages.courses.courses_list_page import CoursesListPage
from pages.courses.create_course_page import CreateCoursePage
import allure
from tools.allure.epics import AllureEpic
from tools.allure.features import AllureFeature
from tools.allure.stories import AllureStory
from allure_commons.types import Severity
from tools.routes import AppRoute
from config import settings

@pytest.mark.regression
@pytest.mark.courses
@allure.epic(AllureEpic.LMS)
@allure.feature(AllureFeature.COURSES)
@allure.story(AllureStory.COURSES)

@allure.parent_suite(AllureEpic.LMS)
@allure.suite(AllureFeature.COURSES)
@allure.sub_suite(AllureStory.COURSES)
class TestCourses:
    @allure.title("Check displaying empty courses list")
    @allure.severity(Severity.NORMAL)
    def test_empty_courses_list(self,courses_list_page: CoursesListPage):
        courses_list_page.visit(AppRoute.COURSES)

        courses_list_page.toolbar_view.check_visible()
        courses_list_page.check_visible_empty_view()

        courses_list_page.sidebar.check_visible()
        courses_list_page.navbar.check_visible(settings.test_user.username)

    @allure.title("Create course")
    @allure.severity(Severity.CRITICAL)
    def test_create_course(self,courses_list_page: CoursesListPage, create_course_page: CreateCoursePage):
        create_course_page.visit(AppRoute.CREATE_COURSE)
        create_course_page.course_toolbar.check_visible_create_course_title()
        create_course_page.course_toolbar.check_visible()

        create_course_page.image_upload_widget.check_visible(is_image_uploaded=False)
        create_course_page.create_course_form_component.check_visible_empty_form(
            title='',
            estimated_time='',
            description='',
            max_score='0',
            min_score='0'
        )
        create_course_page.exercises_toolbar.check_visible()

        create_course_page.check_visible_exercises_empty_view()
        create_course_page.exercises_toolbar.click_create_exercise_button()
        create_course_page.image_upload_widget.upload_preview_image(settings.test_data.image_png_file)
        create_course_page.image_upload_widget.check_visible(is_image_uploaded=True)
        create_course_page.create_course_form_component.fill_form(
            title="Playwright",
            estimated_time="2 weeks",
            description="Playwright",
            max_score="100",
            min_score="10"
        )
        create_course_page.create_course_form_component.check_visible_filled_form(
            title="Playwright",
            estimated_time="2 weeks",
            description="Playwright",
            max_score="100",
            min_score="10"
        )
        create_course_page.course_toolbar.check_visible(is_create_course_disabled=False)
        create_course_page.course_toolbar.click_create_course_button()
        courses_list_page.toolbar_view.check_visible()
        courses_list_page.course_view.check_visible(
            index='0',
            title="Playwright",
            estimated_time="2 weeks",
            max_score="100",
            min_score="10"
        )

    @allure.title("Edit course card")
    def test_edit_course (self,create_course_page: CreateCoursePage,courses_list_page: CoursesListPage):

        create_course_page.visit(AppRoute.CREATE_COURSE)

        create_course_page.image_upload_widget.upload_preview_image(settings.test_data.image_png_file)
        create_course_page.image_upload_widget.check_visible(is_image_uploaded=True)
        create_course_page.create_course_form_component.fill_form(
            title="Playwright",
            estimated_time="2 weeks",
            description="Playwright",
            max_score="100",
            min_score="10"
        )
        create_course_page.create_course_form_component.check_visible_filled_form(
            title="Playwright",
            estimated_time="2 weeks",
            description="Playwright",
            max_score="100",
            min_score="10"
        )
        create_course_page.course_toolbar.check_visible(is_create_course_disabled=False)
        create_course_page.course_toolbar.click_create_course_button()
        courses_list_page.toolbar_view.check_visible()
        courses_list_page.course_view.check_visible(
            index='0',
            title="Playwright",
            estimated_time="2 weeks",
            max_score="100",
            min_score="10"
        )
        courses_list_page.course_menu_component.edit_button(index=0)
        create_course_page.create_course_form_component.fill_form(
            title="Python",
            estimated_time="1 month",
            description="Python",
            max_score="5",
            min_score="2"
        )

        create_course_page.course_toolbar.click_create_course_button()
        courses_list_page.course_view.check_visible(
            title="Python",
            estimated_time="1 month",
            max_score="5",
            min_score="2",
            index='0'
        )






    # with sync_playwright() as playwright:
    #     browser = playwright.chromium.launch(headless=False)
    #     context = browser.new_context()
    #
    #     page = context.new_page()
    #
    #     page.goto('https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/registration')
    #
    #     email_input = page.get_by_test_id('registration-form-email-input').locator('input')
    #     email_input.fill('user.name@gmail.com')
    #
    #     username_input = page.get_by_test_id('registration-form-username-input').locator('input')
    #     username_input.fill('username')
    #
    #     password_input = page.get_by_test_id('registration-form-password-input').locator('input')
    #     password_input.fill('password')
    #
    #     registration_button = page.get_by_test_id('registration-page-registration-button')
    #     registration_button.click()
    #
    #     context.storage_state(path='browser-state_for_courses.json')
    #
    # with sync_playwright() as playwright:
    #     browser = playwright.chromium.launch(headless=False)
    #     context = browser.new_context(storage_state='browser-state_for_courses.json')
    #     page = context.new_page()



        # chromium_page_with_state.goto('https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/courses')
        #
        # header_courses = chromium_page_with_state.get_by_test_id('courses-list-toolbar-title-text')
        # expect(header_courses).to_have_text('Courses')
        #
        # text_block = chromium_page_with_state.get_by_test_id('courses-list-empty-view-title-text')
        # expect(text_block).to_have_text('There is no results')
        #
        # text_block_child = chromium_page_with_state.get_by_test_id('courses-list-empty-view-description-text')
        # expect(text_block_child).to_have_text('Results from the load test pipeline will be displayed here')
        #
        # icon_block = chromium_page_with_state.get_by_test_id('courses-list-empty-view-icon').locator('path')
        # expect(icon_block).to_have_attribute('d','M20 6h-8l-2-2H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2m0 12H4V8h16z')
        #
        #
        # chromium_page_with_state.wait_for_timeout(5000)
