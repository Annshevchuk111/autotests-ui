import pytest
from tools.routes import AppRoute
from tools.allure.epics import AllureEpic
from tools.allure.features import AllureFeature
from tools.allure.stories import AllureStory
from allure_commons.types import Severity
from pages.dashboard.dashboard_page import DashboardPage
from pages.authentication.registration_page import RegistrationPage
import allure


@pytest.mark.regression
@pytest.mark.registration

@allure.epic(AllureEpic.LMS)
@allure.feature(AllureFeature.AUTHENTICATION)
@allure.story(AllureStory.REGISTRATION)

@allure.parent_suite(AllureEpic.LMS)
@allure.suite(AllureFeature.AUTHENTICATION)
@allure.sub_suite(AllureStory.REGISTRATION)
class TestRegistration:
    @allure.title("Registration with correct email,username and password")
    @allure.severity(Severity.CRITICAL)

    @pytest.mark.xdist_group(name="authorization-group")
    def test_successful_registration(self,registration_page: RegistrationPage, dashboard_page: DashboardPage):
        registration_page.visit(AppRoute.REGISTRATION)
        registration_page.registration_form.fill_registration_form(email='user.name@gmail.com', username='username',password='password')
        registration_page.registration_form.check_visible(email='user.name@gmail.com', username='username',password='password')
        registration_page.click_registration_button()

        dashboard_page.dashboard.check_visible()






# Код который был до применения LoginPage POM
    # chromium_page.goto('https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/registration')
    #
    # email_input = chromium_page.get_by_test_id('registration-form-email-input').locator('input')
    # email_input.fill('user.name@gmail.com')
    #
    # username_input = chromium_page.get_by_test_id('registration-form-username-input').locator('input')
    # username_input.fill('username')
    #
    # password_input = chromium_page.get_by_test_id('registration-form-password-input').locator('input')
    # password_input.fill('password')
    #
    # registration_button = chromium_page.get_by_test_id('registration-page-registration-button')
    # registration_button.click()
    #
    # dashboard_title = chromium_page.get_by_test_id('dashboard-toolbar-title-text')
    # expect(dashboard_title).to_be_visible()
    #
