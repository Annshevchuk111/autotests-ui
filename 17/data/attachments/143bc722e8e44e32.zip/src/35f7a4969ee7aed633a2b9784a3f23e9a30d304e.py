import pytest
from pages.authentication.login_page import LoginPage
from pages.authentication.registration_page import RegistrationPage
from pages.dashboard.dashboard_page import DashboardPage
import allure
from tools.allure.tags import AllureTags
from tools.allure.epics import AllureEpic
from tools.allure.features import AllureFeature
from tools.allure.stories import AllureStory
from allure_commons.types import Severity
from tools.routes import AppRoute
from config import settings




@pytest.mark.regression
@pytest.mark.authorization
@allure.tag( AllureTags.AUTHORIZATION,AllureTags.REGRESSION)


@allure.epic(AllureEpic.LMS)
@allure.feature(AllureFeature.AUTHENTICATION)
@allure.story(AllureStory.AUTHORIZATION)

@allure.parent_suite(AllureEpic.LMS)
@allure.suite(AllureFeature.AUTHENTICATION)
@allure.sub_suite(AllureStory.AUTHORIZATION)
class TestAuthorization:
    @allure.title("User login with correct email and password")
    @allure.tag(AllureTags.USER_LOGIN)
    @allure.severity(Severity.BLOCKER)
    def test_successful_authorization(
            self,
            dashboard_page:DashboardPage,
            registration_page: RegistrationPage,
            login_page: LoginPage,
    ):
        registration_page.visit(AppRoute.REGISTRATION)
        registration_page.registration_form.fill_registration_form(
            email=settings.test_user.email,
            username=settings.test_user.username,
            password=settings.test_user.password)
        registration_page.click_registration_button()

        dashboard_page.dashboard.check_visible()
        dashboard_page.navbar.check_visible(settings.test_user.username)
        dashboard_page.sidebar.check_visible()
        dashboard_page.sidebar.click_logout()



        login_page.login_form.fill_login_form(
            email=settings.test_user.email,
            password=settings.test_user.password)
        login_page.click_login_button()

        dashboard_page.dashboard.check_visible()
        dashboard_page.navbar.check_visible(settings.test_user.username)
        dashboard_page.sidebar.check_visible()



    @pytest.mark.parametrize('email,password', [
        ('user.name@gmail.com', 'password'),
        ('user.name@gmail.com', '  '),
        ('  ', 'password')

    ])
    @allure.title('User login with wrong email or password')
    @allure.tag(AllureTags.USER_LOGIN)
    @allure.severity(Severity.CRITICAL)

    @pytest.mark.xdist_group(name="authorization-group")
    def test_wrong_email_or_password_authorization(self,login_page: LoginPage, email: str, password: str):


        login_page.visit("https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/login")
        login_page.login_form.fill_login_form(email=email, password=password)
        login_page.login_form.check_visible(email=email, password=password)
        login_page.click_login_button()
        login_page.check_visible_wrong_email_or_password_alert()

    @allure.title('Navigation from login page to registration page')
    @allure.tag(AllureTags.NAVIGATION)
    @allure.severity(Severity.NORMAL)
    def test_navigate_rom_authorization_to_registration(
            self,
            login_page: LoginPage,
            registration_page: RegistrationPage,
        ):
        login_page.visit('https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/login')
        login_page.click_registration_link()
        registration_page.registration_form.check_visible(email='',username='',password='')




#Код который был до применения LoginPage POM
    # chromium_page.goto("https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/login")
    # email_input = chromium_page.get_by_test_id("login-form-email-input").locator('input')
    # email_input.fill(email)
    #
    # password_input = chromium_page.get_by_test_id("login-form-password-input").locator('input')
    # password_input.fill(password)
    #
    # login_button = chromium_page.get_by_test_id("login-page-login-button")
    # login_button.click()
    #
    # wrong_email_or_password_alert = chromium_page.get_by_test_id("login-page-wrong-email-or-password-alert")
    # expect(wrong_email_or_password_alert).to_be_visible()
    # expect(wrong_email_or_password_alert).to_have_text('Wrong email or password')

