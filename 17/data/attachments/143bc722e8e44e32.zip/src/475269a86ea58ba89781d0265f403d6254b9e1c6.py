from playwright.sync_api import sync_playwright, Page, Playwright
import pytest
from pages.authentication.registration_page import RegistrationPage
from _pytest.fixtures import SubRequest
from config import settings
import allure
from allure_commons.types import AttachmentType
from tools.playwright.pages import initialize_page

@pytest.fixture(params=settings.browsers)
def page(request:SubRequest ,playwright:Playwright) -> Page:
    yield from initialize_page(
        playwright,
        test_name=request.node.name,
        browser_type=request.param
    )

@pytest.fixture(scope="session")
def initialize_browser_state(playwright:Playwright) -> Page:
    browser = playwright.chromium.launch(headless=settings.headless)
    context = browser.new_context(base_url=settings.get_base_url())

    page = context.new_page()

    registration_page = RegistrationPage(page=page)
    registration_page.visit('https://nikita-filonov.github.io/qa-automation-engineer-ui-course/#/auth/registration')

    registration_page.registration_form.fill_registration_form(
        email=settings.test_user.email,
        username=settings.test_user.username,
        password=settings.test_user.password)
    registration_page.click_registration_button()

    context.storage_state(path=settings.browser_state_file)
    browser.close()

@pytest.fixture(params=settings.browsers)
def page_with_state(request:SubRequest,initialize_browser_state,playwright:Playwright) -> Page:
    yield from initialize_page(
        playwright,
        test_name=request.node.name,
        browser_type=request.param,
        storage_state=settings.browser_state_file
    )

